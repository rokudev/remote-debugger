########################################################################
# Copyright 2019-2020 Roku, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
########################################################################

# File: DebuggerRequest.py
# Requires python v3.5.3 or later
#
# NAMING CONVENTIONS:
#
# TypeIdentifiers are CamelCase
# CONSTANTS are CAPITAL_CASE
# all_other_identifiers are snake_case
# _protected members begin with a single underscore '_' (subclasses can access)
# __private members begin with double underscore: '__'
#
# python more or less enfores the double-underscore as private
# by prepending the class name to those identifiers. That makes
# it difficult (but not impossible) for other classes to access
# those identifiers.

import copy, enum, sys, traceback

global_config = getattr(sys.modules['__main__'], 'global_config', None)
assert global_config    # verbosity, global debug_level

UINT8_SIZE = 1
UINT32_SIZE = 4

# Size in bytes of a simple request with no parameters:
#    - packetSize,requestID,cmdCode
NO_PARAMS_REQUEST_SIZE = (3 * UINT32_SIZE)

@enum.unique
class CmdCode(enum.IntEnum):
    # Skip value 0 because it is confused with None
    STOP = 1,
    CONTINUE = 2,
    THREADS = 3,
    STACKTRACE = 4,
    VARIABLES = 5,
    STEP = 6,
    ADD_BREAKPOINTS = 7,
    LIST_BREAKPOINTS = 8,
    REMOVE_BREAKPOINTS = 9,

    EXIT_CHANNEL = 122,

    # string displayable to an end user
    def to_user_str(self):
        return '{}({})'.format(self.name, self.value)


@enum.unique
class StepType(enum.IntEnum):
    UNDEF = 0,      # Uninitialized value, should not be sent over protocol
    LINE = 1,
    OUT = 2,
    OVER = 3,

@enum.unique
class _VariablesRequestFlags(enum.IntEnum):
    # These values must fit in 8 bits
    GET_CHILD_KEYS = 0x01


# Abstract base class of all debugger requests
class DebuggerRequest(object):

    # Upon return the attribute packet_size will be set to the base
    # (no params) packet size. Subclasses should adjust this value in
    # their constructors, after invoking this constructor.
    # All debugger requests have a caller_data attribute. caller_data
    # is an opaque value that is ignored by the debugger client, and the
    # caller can manipulate that data at will
    def __init__(self, cmdCode, caller_data=None):
        self.__local_debug_level = 0
        self.cmd_code = cmdCode
        self.request_id = None          # Set when sent to debuggee
        self.caller_data = caller_data
        self.packet_size = NO_PARAMS_REQUEST_SIZE

    def __str__(self):
        s = '{}[{}]'.format(type(self).__name__, self._str_params())
        return s

    # parameters inside the response to __str__()
    def _str_params(self):
        s = 'cmdcode={},size={},reqid={}'.format(
                repr(self.cmd_code), self.packet_size, self.request_id)
        if self.caller_data:
            s += ',cdata={}'.format(self.caller_data)
        return s

    # python makes some whacky decision when choosing repr() vs. str()
    # let's just make 'em the same
    def __repr__(self):
        return self.__str__()

    # Send the fields common to all requests: packetSize,requestID,cmdCode
    # REQUIRES: self.packet_size has been set
    # @return number of bytes written
    def _send_base_fields(self, debugger_client):
        assert self.cmd_code
        assert self.packet_size > 0
        assert self.request_id
        dclient = debugger_client
        if self._debug_level() >= 5:
            print('debug: send base fields {}({}), packet_size={},requestID={}'.\
                format(
                    self.cmd_code.name,
                    self.cmd_code.value,
                    self.packet_size,
                    self.request_id))
        count = 0
        count += dclient.send_uint(self.packet_size)
        count += dclient.send_uint(self.request_id)
        count += dclient.send_uint(self.cmd_code)
        self.__verify_num_written(NO_PARAMS_REQUEST_SIZE, count)
        return count

    # raise an exception if the counts don't match
    # @return actual value, if it matches expectations
    def __verify_num_written(self, expected, actual):
        if expected == actual:
            return actual
        raise AssertionError(
            'INTERNAL ERROR: bad size written expected={},actual={}'.format(
                expected, actual))

    def _debug_level(self):
        return max(global_config.debug_level, self.__local_debug_level)


# Private subclass
class _DebuggerRequest_NoParams(DebuggerRequest):
    def __init__(self, cmd_code, caller_data=None):
        super(_DebuggerRequest_NoParams, self).\
                __init__(cmd_code, caller_data=caller_data)
        self.__local_debug_level = 0

    def _debug_level(self):
        return max(global_config.debug_level, self.__local_debug_level)

    # Intended for use only within this package (e.g., from DebuggerClient)
    # @return number of bytes written
    def _send(self, debugger_client):
        if self._debug_level() >= 2:
            print('debug: drqst: send {}'.format(self))
        return self._send_base_fields(debugger_client)


class DebuggerRequest_AddBreakpoints(DebuggerRequest):

    def __init__(self, breakpoints, caller_data=None):
        super(DebuggerRequest_AddBreakpoints, self).\
                __init__(CmdCode.ADD_BREAKPOINTS, caller_data=caller_data)
        if not (breakpoints and len(breakpoints)):
            raise ValueError
        breakpoints = copy.deepcopy(breakpoints)
        self.__local_debug_level = 0

        # Adjust the packet size, for the additional fields
        # request is base +
        #    uint32:num_breakpoints,
        #    breakpoint_spec[]:
        #        utf8z:file_path
        #        uint32:line_num
        #        uint32:ignore_count
        #    ... breakpoint_spec repeated num_breakpoints times
        self.packet_size += UINT32_SIZE
        try:
            for one_break in breakpoints:
                # encode() does not include trailing 0
                self.packet_size += len(one_break.file_path.encode('utf-8')) + 1
                self.packet_size += (2*UINT32_SIZE)
        except Exception:
            if self._debug_level() >= 5:
                print('debug: exception:')
                traceback.print_exc(file=sys.stdout)
            raise ValueError
        self.breakpoints = breakpoints

    # Intended for use only within this package
    def _send(self, debugger_client):
        dclient = debugger_client
        self._send_base_fields(dclient)
        dclient.send_uint(len(self.breakpoints))
        for one_break in self.breakpoints:
            dclient.send_str(one_break.file_path)
            dclient.send_uint(one_break.line_num)
            dclient.send_uint(one_break.ignore_count)

    def _str_params(self):
        s = super(DebuggerRequest_AddBreakpoints, self)._str_params()
        s += ',breakpoints=['
        need_comma = False
        for breakpoint in self.breakpoints:
            if need_comma:
                s += ','
            need_comma = True
            s += '{}:{}.ign={}'.format(
                breakpoint.file_path, breakpoint.line_num,
                breakpoint.ignore_count)
        return s

    def _debug_level(self):
        return max(global_config.debug_level, self.__local_debug_level)

# END class DebuggerRequest_AddBreakpoints


class DebuggerRequest_Continue(_DebuggerRequest_NoParams):
    def __init__(self, caller_data=None):
        super(DebuggerRequest_Continue, self).\
            __init__(CmdCode.CONTINUE, caller_data=caller_data)


class DebuggerRequest_ExitChannel(_DebuggerRequest_NoParams):
    def __init__(self, caller_data=None):
        super(DebuggerRequest_ExitChannel, self).\
                    __init__(CmdCode.EXIT_CHANNEL, caller_data=caller_data)


class DebuggerRequest_ListBreakpoints(_DebuggerRequest_NoParams):
    def __init__(self, caller_data=None):
        super(DebuggerRequest_ListBreakpoints, self).__init__(
                CmdCode.LIST_BREAKPOINTS, caller_data=caller_data)


class DebuggerRequest_RemoveBreakpoints(DebuggerRequest):

    def __init__(self, breakpoint_ids, caller_data=None):
        super(DebuggerRequest_RemoveBreakpoints, self).\
                __init__(CmdCode.REMOVE_BREAKPOINTS, caller_data=caller_data)
        if not (breakpoint_ids and len(breakpoint_ids)):
            raise ValueError
        self.breakpoint_ids = copy.copy(breakpoint_ids)

        # Adjust the packet size, for the additional fields
        # request is base +
        #    uint32:num_breakpoints,
        #        uint32 breakpoint_id
        #        ... breakpoint_id repeated num_breakpoints times
        self.packet_size += ((1+len(self.breakpoint_ids)) * UINT32_SIZE)

    # Intended for use only within this package
    def _send(self, debugger_client):
        dclient = debugger_client
        self._send_base_fields(dclient)
        dclient.send_uint(len(self.breakpoint_ids))
        for one_id in self.breakpoint_ids:
            dclient.send_uint(one_id)
# END class DebuggerRequest_RemoveBreakpoints

# Get stack trace of one stopped thread
class DebuggerRequest_Stacktrace(DebuggerRequest):
    def __init__(self, thread_index, caller_data=None):
        super(DebuggerRequest_Stacktrace, self).\
                        __init__(CmdCode.STACKTRACE, caller_data=caller_data)
        self.packet_size += UINT32_SIZE
        self.thread_index = thread_index
        return

    # Intended for use only within this package
    def _send(self, debugger_client):
        self._send_base_fields(debugger_client)
        debugger_client.send_uint(self.thread_index)

    def _str_params(self):
        s = super(DebuggerRequest_Stacktrace, self)._str_params()
        s += ',thidx={}'.format(self.thread_index)
        return s


# Step (briefly execute) one thread
# @param step_type enum StepType
class DebuggerRequest_Step(_DebuggerRequest_NoParams):

    def __init__(self, thread_index, step_type, caller_data=None):
        assert isinstance(step_type, StepType)
        super(DebuggerRequest_Step,self).__init__(CmdCode.STEP,
            caller_data=caller_data)
        self.__thread_index = thread_index
        self.__step_type = step_type

        self.packet_size += (UINT32_SIZE + UINT8_SIZE)

    # Intended for use only within this package
    def _send(self, debugger_client):
        self._send_base_fields(debugger_client)
        debugger_client.send_uint(self.__thread_index)
        debugger_client.send_byte(self.__step_type.value)

    def _str_params(self):
        s = super(DebuggerRequest_Step, self)._str_params()
        s += ',thidx={}'.format(self.__thread_index)
        s += ',steptype={}'.format(str(self.__step_type))
        return s


# Stop all threads
class DebuggerRequest_Stop(_DebuggerRequest_NoParams):
    def __init__(self, caller_data=None):
        super(DebuggerRequest_Stop,self).__init__(CmdCode.STOP,
                    caller_data=caller_data)

# Enumerate all threads
class DebuggerRequest_Threads(_DebuggerRequest_NoParams):
    def __init__(self, caller_data=None):
        super(DebuggerRequest_Threads, self).\
                        __init__(CmdCode.THREADS, caller_data=caller_data)


########################################################################
# VARIABLES
########################################################################

# Get variables accessible from a given stack frame
class DebuggerRequest_Variables(DebuggerRequest):

    # Get the value of a variable, referenced from the specified
    # stack frame. The path may be None or an empty array, which
    # specifies the local variables in the specified frame.
    # @param thread_index index of the thread to be examined
    # @param frame_index index of the stack frame on the specified thread
    # @param variable_path array of strings, path to variable to inspect
    # @param get_keys if True get the keys in the container variable
    def __init__(self, thread_index, frame_index, variable_path,
                    get_child_keys, caller_data=None):
        super(DebuggerRequest_Variables, self).\
                __init__(CmdCode.VARIABLES, caller_data=caller_data)

        assert (thread_index != None) and (int(thread_index) >= 0)
        assert (frame_index != None) and (int(frame_index) >= 0)
        assert ((get_child_keys == True) or (get_child_keys == False))
        assert ((variable_path == None) or (len(variable_path) >= 0))

        self.get_child_keys = get_child_keys
        self.thread_index = thread_index
        self.frame_index = frame_index
        if not variable_path:
            self.variable_path = []
        else:
            self.variable_path = variable_path
        # request is base +
        #    uint8: request flags (see enum _VariableRequestFlags)
        #    uint32:thread_index,
        #    uint32:frame_index
        #    uint32:variable_path_len,
        #    char*[]:variable_path
        self.packet_size += (UINT8_SIZE + (3 * UINT32_SIZE))
        for elem in self.variable_path:
            # encode() does not include trailing 0
            self.packet_size += len(elem.encode('utf-8')) + 1

    # parameters inside the result of __str__()
    def _str_params(self):
        return '{},thridx={},frmidx={},getchildkeys={},varpath={}'.format(
            super(DebuggerRequest_Variables, self)._str_params(),
            self.thread_index,
            self.frame_index,
            self.get_child_keys,
            self.variable_path)

    # Intended for use only within this package
    def _send(self, debugger_client):
        self._send_base_fields(debugger_client)
        dc = debugger_client
        flags = 0
        if self.get_child_keys:
            flags |= _VariablesRequestFlags.GET_CHILD_KEYS
        dc.send_byte(flags)
        dc.send_uint(self.thread_index)
        dc.send_uint(self.frame_index)
        dc.send_uint(len(self.variable_path))
        for elem in self.variable_path:
            dc.send_str(elem)
        if self._debug_level() >= 5:
            print('debug: sent VARIABLES cmd: {}'.format(self))


def do_exit(errCode, msg=None):
    sys.modules['__main__'].do_exit(errCode, msg)
