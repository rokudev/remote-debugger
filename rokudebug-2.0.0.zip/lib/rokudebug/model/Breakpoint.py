########################################################################
# Copyright 2019-2020 Roku, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
########################################################################

# File: Breakpoint.py
# Requires python v3.5.3 or later
#
# NAMING CONVENTIONS:
#
# TypeIdentifiers are CamelCase
# CONSTANTS_ARE CAPITALIZED_SNAKE_CASE
# all_other_identifiers are lower_snake_case
# _protected members begin with a single underscore '_' (avail to friends)
# __private members begin with double underscore: '__'
#
# python more or less enforces the double-underscore as private
# by prepending the class name to those identifiers. That makes
# it difficult (but not impossible) for other classes to access
# those identifiers.

import sys

global_config = getattr(sys.modules['__main__'], 'global_config', None)
assert global_config    # verbosity, global debug_level

class Breakpoint(object):
    def __init__(self, file_path, line_num, ignore_count=0):
        if not (file_path and line_num):
            raise ValueError
        self.__debug = 0
        self.__debug = max(global_config.debug_level, 0)
        self.file_path = file_path
        self.line_num = line_num
        self.local_id = None    # ID assigned locally, presented to user
        self.remote_id = None   # ID assigned by debugging target
        self.ignore_count = ignore_count

    # The ID used locally and presented to the user
    def set_local_id(self, local_id):
        self.local_id = local_id

    # The ID assigned by the debugging target
    def set_remote_id(self, remote_id):
        self.remote_id = remote_id

    def is_on_device(self):
        return (self.remote_id != None)

    def is_enabled(self):
        return self.is_on_device()

    def __str__(self):
        s = 'Breakpoint[{}:{}'.format(self.file_path, self.line_num)
        if self.local_id:
            s += ',localid={}'.format(self.local_id)
        if self.remote_id:
            s += ',rmtid={}'.format(self.remote_id)
        if self.ignore_count:
            s += ',ignorecount={}'.format(self.ignore_count)
        s += ']'
        return s


import sys
def do_exit(errCode, msg=None):
    sys.modules['__main__'].do_exit(errCode, msg)
