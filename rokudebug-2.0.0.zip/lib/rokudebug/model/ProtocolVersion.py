########################################################################
# Copyright 2019-2020 Roku, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
########################################################################

# File: ProtocolVersion.py
# Requires python v3.5.3 or later
#
# Defines which protocol versions are supported by this debugger
#

import enum, sys

global_config = getattr(sys.modules['__main__'], 'global_config', None)
assert global_config    # verbosity, global debug_level, do_exit()

_SUPPORTED_PROTOCOL_MAJOR_VERSIONS = [1,2] # must be array (list does not support "in")

@enum.unique
class ProtocolFeature(enum.IntEnum):
    UNDEF = 0,
    STOP_ON_LAUNCH_ALWAYS = enum.auto()
    BAD_LINE_NUMBER_IN_STOP_BUG = enum.auto()
    BREAKPOINTS = enum.auto()
    STEP_COMMANDS = enum.auto()

    # Roku O.S. sends an incorrect THREAD_ATTACHED msg during step in/over/out
    ATTACHED_MESSAGE_DURING_STEP_BUG = enum.auto()

    def to_user_string(self):
        feature = ProtocolFeature
        user_string = self.name().lower()
        # Special cases
        if self.value == feature.STOP_ON_LAUNCH_ALWAYS:
            user_string = "stop on launch"  # To user, it's not "always"
        return user_string

class ProtocolVersion(object):

    # @param major, minor, patch_level : int
    def __init__(self, major, minor, patch_level):
        self.major = major
        self.minor = minor
        self.patch_level = patch_level

    def __str__(self):
        return self.to_user_str()

    def __eq__(self, other):
        return self.__to_int() == other.__to_int()
    def __ne__(self, other):
        return self.__to_int() != other.__to_int()
    def __gt__(self, other):
        return self.__to_int() > other.__to_int()
    def __ge__(self, other):
        return self.__to_int() >= other.__to_int()
    def __lt__(self, other):
        return self.__to_int() < other.__to_int()
    def __le__(self, other):
        return self.__to_int() <= other.__to_int()

    @staticmethod
    def get_max_version():
        max_ver = ProtocolVersion(999,999,99999999)
        assert max_ver.is_valid()
        return max_ver

    # Very simplistic check on the validity of the version parts
    # (e.g., not negative, not ridiculously large)
    def is_valid(self):
        # patch_level can be a date, e.g. 20200214
        return self.major >= 0 and self.major <= 999 and \
                self.minor >= 0 and self.minor <= 999 and \
                self.patch_level >= 0 and self.patch_level <= 99999999

    # Safe for display to user
    def to_user_str(self):
        return '{}.{}.{}'.format(self.major, self.minor, self.patch_level)

    # @param feature enum ProtocolFeature
    def has_feature(self, feature):
        has_it = False

        # 1.1
        if feature == ProtocolFeature.STEP_COMMANDS:
            has_it = self >= ProtocolVersion(1,1,0)

        # 1.1.1
        elif feature == ProtocolFeature.BAD_LINE_NUMBER_IN_STOP_BUG:
            has_it = self >= ProtocolVersion(1,1,1)

        # 1.2
        elif feature == ProtocolFeature.BREAKPOINTS:
            has_it = self >= ProtocolVersion(1,2,0)

        # 2.0
        elif feature == ProtocolFeature.STOP_ON_LAUNCH_ALWAYS:
            has_it = self >= ProtocolVersion(2,0,0)
        elif feature == ProtocolFeature.ATTACHED_MESSAGE_DURING_STEP_BUG:
            has_it = self >= ProtocolVersion(2,0,0)

        return has_it

    # In python 3, "All integers are implemented as long integer
    # objects of arbitrary size."
    def __to_int(self):
        assert self.is_valid()
        # python has unlimited precision
        return self.major * int(1e+9) + \
                    self.minor * int(1e+6) + \
                    self.patch_level


########################################################################
# Global functions
########################################################################

def get_supported_protocol_major_versions():
    return _SUPPORTED_PROTOCOL_MAJOR_VERSIONS

def get_supported_protocols_str():
    supported_str = ''
    for one_ver in sorted(_SUPPORTED_PROTOCOL_MAJOR_VERSIONS):
        if len(supported_str):
            supported_str += ','
        supported_str += '{}.x'.format(one_ver)
    return supported_str

# Exits this script if this client's protocol version is not
# compatible with any of this debugger's supported_versions.
# @param debuggee_version: ProtocolVersion
# @return void
def check_debuggee_protocol_version(debuggee_version):
    if debuggee_version.major not in _SUPPORTED_PROTOCOL_MAJOR_VERSIONS:
        msg = 'Unsupported protocol version: {}'.format(
                debuggee_version.to_user_str())
        print(msg, file=sys.stderr)
        print('Protocol versions supported are: {}'.format(
                get_supported_protocols_str()),
            file=sys.stderr)
        do_exit(1, msg)

def do_exit(exit_code, msg=None):
    global_config.do_exit(exit_code, msg)
