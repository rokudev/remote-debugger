########################################################################
# Copyright 2019-2020 Roku, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
########################################################################
# File: CommandLineCompleter.py
# Requires python 3.5.3 or later
#
# NAMING CONVENTIONS:
#
# TypeNames are CamelCase
# CONSTANT_VALUES are CAPITAL_CASE
# all_other_identifiers are snake_case
# _protected members begin with a single underscore '_' (subclasses can access)
# __private members begin with double underscore: '__'
#
# python more or less enforces the double-underscore as private
# by prepending the class name to those identifiers. That makes
# it difficult (but not impossible) for other classes to access
# those identifiers.

import sys

from .LineEditor import LineEditor

global_config = getattr(sys.modules['__main__'], 'global_config', None)
assert global_config    # verbosity, global debug_level

class CommandLineCompleter(object):

    def __init__(self, cli):
        self.__debug_level = max(global_config.debug_level, 0)
        self.__cli = cli

    def get_completions(self, full_text, beginidx, endidx):
        completions = None
        token_info, selidx = LineEditor.parse_tokens(full_text, beginidx, endidx)
        token = None
        if selidx >= 0:
            token = token_info[selidx]['text']
        if (selidx == -1) or (not (token_info and len(token_info))):
            # Empty commmand line
            completions = self.__cli._get_all_cmd_strs().sort()
        elif selidx < 0:
            if self.__debug_level >= 2:
                completions = ['<debug:after:{}>'.format((-selidx)-2)]
        elif selidx == 0:
            completions = self.__complete_command(token)
        elif selidx == 1:
            completions = self.__complete_file_name(token)
        return completions

    def __complete_command(self, token):
        completions = list()

        # Look for exact match to an alias
        aliases = self.__cli._get_all_cmd_aliases()
        for alias_pair in aliases:
            if alias_pair[0] == token:
                completions.append(alias_pair[1])

        extraps = self.__find_extrapolations(
                        token, self.__cli._get_all_cmd_strs())
        if extraps:
            completions.extend(extraps)

        # sort and unique the list
        completions = list(set(completions))
        completions.sort()
        return completions

    def __complete_file_name(self, token):
        if self.__debug_level >= 3:
            print('debug: clcomp: completefile({})'.format(token))
        completions = list()
        cmp_token = token.casefold()
        for file_path in self.__cli._src_inspector.get_source_file_paths():
            if cmp_token in file_path.casefold():
                completions.append(file_path)
        return completions

    # Find elements of possibilities that start with stem, or == stem
    # @return list of extrapolations or None
    def __find_extrapolations(self, stem, possibilities):
        extraps = []
        for poss in possibilities:
            if poss.startswith(stem):
                extraps.append(poss)
        if not len(extraps):
            extraps = None
        return extraps
